Config = {}

-- Define backpack items and their properties
Config.Backpacks = {
    small = {
        label = "Small Backpack",
        slots = 10,
        weight = 20,
        prop = "prop_backpack_01"
    },
    medium = {
        label = "Medium Backpack",
        slots = 20,
        weight = 40,
        prop = "prop_backpack_02"
    },
    large = {
        label = "Large Backpack",
        slots = 30,
        weight = 60,
        prop = "prop_backpack_03"
    }
}

-- Command to open backpack
Config.OpenCommand = "backpack"