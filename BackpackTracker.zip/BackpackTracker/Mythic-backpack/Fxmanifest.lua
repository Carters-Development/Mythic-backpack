fx_version 'cerulean'
game 'gta5'

description 'Mythic Backpack System'
author 'carters-Development'

client_script 'client.lua'
server_script 'server.lua'
shared_script 'config.lua'

ui_page 'html/ui.html'

files {
    'html/ui.html',
    'html/style.css',
    'html/script.js'
}