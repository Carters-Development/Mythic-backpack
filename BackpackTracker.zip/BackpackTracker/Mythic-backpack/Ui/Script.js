window.addEventListener('message', function(event) {
  if (event.data.action === "open") {
      document.getElementById('backpack').style.display = 'block';
      // Populate items
  }
});

function closeBackpack() {
  document.getElementById('backpack').style.display = 'none';
  fetch(`https://${GetParentResourceName()}/close`, {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json; charset=UTF-8',
      },
      body: JSON.stringify({})
  });
}