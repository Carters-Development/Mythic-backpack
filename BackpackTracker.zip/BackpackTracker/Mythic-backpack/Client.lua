local currentBackpack = nil

RegisterCommand(Config.OpenCommand, function()
    if currentBackpack then
        -- Open backpack UI
        SetNuiFocus(true, true)
        SendNUIMessage({ action = "open", items = currentBackpack.items })
    else
        TriggerEvent('mythic_notify:client:SendAlert', { type = 'inform', text = 'You are not wearing a backpack.' })
    end
end, false)

RegisterNUICallback("close", function()
    SetNuiFocus(false, false)
end)

RegisterNUICallback("storeItem", function(data, cb)
    -- Logic to store item in backpack
    cb("ok")
end)

RegisterNUICallback("retrieveItem", function(data, cb)
    -- Logic to retrieve item from backpack
    cb("ok")
end)

-- Function to equip backpack
function EquipBackpack(backpackType)
    local backpack = Config.Backpacks[backpackType]
    if backpack then
        currentBackpack = {
            type = backpackType,
            items = {},
            slots = backpack.slots,
            weight = backpack.weight
        }
        -- Add visual prop
        local playerPed = PlayerPedId()
        local model = GetHashKey(backpack.prop)
        RequestModel(model)
        while not HasModelLoaded(model) do
            Wait(100)
        end
        local prop = CreateObject(model, 0, 0, 0, true, true, true)
        AttachEntityToEntity(prop, playerPed, GetPedBoneIndex(playerPed, 24818), 0.0, -0.2, -0.05, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
    end
end